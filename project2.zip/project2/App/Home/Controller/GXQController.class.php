<?php
namespace Home\Controller;
use Think\Controller;
class GXQController extends Controller {
    public function index(){
        $this->display('GXQ/GXQ_index');
    }
}