<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script type="text/javascript" src="http://localhost/eclipse/project2/public/js/jquery-2.2.0.js">
    </script>
    <script type="text/javascript" src="http://localhost/eclipse/project2//public/js/bootstrap.min.js">
    </script>
    <link href="http://localhost/eclipse/project2/public/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="http://localhost/eclipse/project2/public/css/css_index.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="http://localhost/dev/simditor/styles/simditor.css" />

    <script type="text/javascript" src="http://localhost/eclipse/project2/public/simditor-2.3.6/scripts/jquery.min.js"></script>
    <script type="text/javascript" src="http://localhost/eclipse/project2/public/simditor-2.3.6/scripts/module.js"></script>
    <script type="text/javascript" src="http://localhost/eclipse/project2/public/simditor-2.3.6/scripts/hotkeys.js"></script>
    <script type="text/javascript" src="http://localhost/eclipse/project2/public/simditor-2.3.6/scripts/uploader.js"></script>
    <script type="text/javascript" src="http://localhost/eclipse/project2/public/simditor-2.3.6/scripts/simditor.js"></script>
   
</head>
<body style="background-color: #FBF4F4">
	<div class="container" style="height:1000px">
	<br>
	<br>
		<form action="http://localhost/eclipse/project2/index.php/Home/AboutUs/EditDes" method="post">
             
             <textarea id="editor" name="editor" autofocus>
             </textarea>
             
             <script type="text/javascript">   
             	$(function(){	
             		toolbar = [ 'title', 'bold', 'italic', 'underline', 'strikethrough',			
             		            'color', '|', 'ol', 'ul', 'blockquote', 'code', 'table', '|',			
             		            'link', 'image', 'hr', '|', 'indent', 'outdent' ];	
             		var editor = new Simditor( {		
             			textarea : $('#editor'),		
             			placeholder : '这里输入内容...',		
             			toolbar : toolbar,  //工具栏		
             			defaultImage : 'http://localhost/eclipse/project2/public/simditor-2.3.6/images/image.png', //编辑器插入图片时使用的默认图片		
             			upload : {		    
             				url : 'http://localhost/eclipse/project2/index.php/Home/Aboutus/UploadIMG', //文件上传的接口地址		    
             				params: null, //键值对,指定文件上传接口的额外参数,上传的时候随文件一起提交		    
             				fileKey: 'fileDataFileName', //服务器端获取文件数据的参数名		    
             				connectionCount: 3,		    
             				leaveConfirm: '正在上传文件'		
             				
             			} 	
             		});   
             		
             	})
             </script>
             <br>
             <button class="btn btn-default" type="submit">提交</button>
        </form>
	</div>
</body>
</html>