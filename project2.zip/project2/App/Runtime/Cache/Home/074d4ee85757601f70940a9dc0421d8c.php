<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body background="http://www.weikeweike.cn//public/images/bg.gif">
<h1 align="center">这是职称评定页面</h1>
<br>
<br>
<br>
<br>
</body>
</html>