<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style type="text/css">
.main{
background:#0066FF;
width:800px;
height:500px;
margin:0 auto;
}
</style>
</head>
<body>


<div class = "main">
	<p align = "center">
		<embed class="main" src ="http://localhost/eclipse/project2/public/game/cyhx.swf" />
	</p>  	
</div>
</body>
</html>