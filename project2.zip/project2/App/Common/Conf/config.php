<?php
return array(
	//'閰嶇疆椤�'=>'閰嶇疆鍊�'
    //user相关数据
    'LoginName'=>'',
    
    //数据库相关数据
    'DB_TYPE'=>'mysql',
    'DB_HOST'=>'localhost',
    'DB_NAME'=>'phpproject1',
    'DB_USER'=>'root',
    'DB_PWD'=>'',
    'DB_PORT'=>'3306',
    'DB_PREFIX'=>'p_',
    
    //地址
    'URLSET'=>'www.weikeweike.cn/',
    
    'DEFAULT_MODULE'=>  'Home',  // 默认模块
    'DEFAULT_CONTROLLER'    =>  'Main', // 默认控制器名称
    'DEFAULT_ACTION'        =>  'index',
);